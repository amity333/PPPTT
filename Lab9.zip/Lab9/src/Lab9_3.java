import java.time.LocalDate;

import org.junit.*;

import src.com.cg.eis.exception.EmployeeException;
import src.com.cg.eis.pl.ServiceMain;

public class Lab9_3 {
	
	static ServiceMain sm = null;
	
	@BeforeClass
	public static void setUp()
	{
		sm = new ServiceMain();
	}
	
	@AfterClass
	public static void atEnd()
	{
		System.out.println("All the functions are tested successfully");
	}
	
	@Before
	public void befTest()
	{
		System.out.println("Test starts");
	}
	
	@After
	public void aftTest()
	{
		System.out.println("Test ends");
	}
	
	@Test(expected = Exception.class)
	public void Test1() throws Exception
	{
		
			sm.retSal();
		
	}
}
