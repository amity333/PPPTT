
public class Person {
String firstName, lastName,phoneNumber;
Gender gender;

Person()
{
firstName="";
lastName="";
gender=Gender.M;
phoneNumber="0123456789";
}

Person(String firstName1,String lastName1, Gender gender1, String phoneNumber1 )
{
	firstName=firstName1;
	lastName=lastName1;
	gender=gender1;
	phoneNumber=phoneNumber1;
}
public void setPhoneNumber(String phoneNumber1)
{
	phoneNumber=phoneNumber1;
}
public void setLastName(String lastName1)
{
	lastName=lastName1;
}
public void setGender(Gender gender1)
{
	gender=gender1;
}
public void setFirstName(String firstName1)
{
	firstName=firstName1;
}

public String getFirstName()
{
	return firstName;
}
public String getLastName()
{
	return lastName;
}
public Gender getGender()
{
	return gender;
}
public String getPhoneNumber()
{
	return phoneNumber;
}
}
