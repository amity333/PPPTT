package src.com.cg.eis.pl;

import src.com.cg.eis.bean.*;
import src.com.cg.eis.exception.*;
import src.com.cg.eis.service.Service;

import java.util.*;

public class ServiceMain {
	
	Employee e1 = null;
	public static void main(String args[])throws Exception
	{
		Scanner sc = new Scanner(System.in);
		String name="", designation="", insuranceScheme = "";
		int id=0, salary=0;
		System.out.println("Enter name");
		name = sc.nextLine();
		System.out.println("Enter id");
		id = Integer.parseInt(sc.nextLine());
		System.out.println("Enter designation");
		designation = sc.nextLine();
		System.out.println("Enter salary");
		salary = Integer.parseInt(sc.nextLine());
		
		
		Service s1 = new Service();
		insuranceScheme = s1.findInsurance(salary, designation);
		Employee e1 = new Employee(name, designation, id, salary, insuranceScheme);
		System.out.println(e1);
	    
		ServiceMain sm = new ServiceMain();
		sm.retSal();
		

	}
	
	public void retSal()throws Exception
	{
		try{e1.getSalary();}
		
		catch(Exception e) {
			throw new Exception("Error");
			
		}
	}
}
