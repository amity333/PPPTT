import java.time.LocalDate;

import org.junit.*;
public class TestDate {
	static Date date1 = null;
	static int day, month, year;
	@BeforeClass
	public static void setUp()
	{
		LocalDate ld = LocalDate.now();
		day = ld.getDayOfMonth();
		month = ld.getMonthValue();
		year = ld.getYear();
		
		date1 = new Date(day, month, year);
		System.out.println("Functions testing starts");
	}
	
	@AfterClass
	public static void atEnd()
	{
		System.out.println("All the functions are tested successfully");
	}
	
	@Before
	public void befTest()
	{
		System.out.println("Test starts");
	}
	
	@After
	public void aftTest()
	{
		System.out.println("Test ends");
	}
	
	@Test
	public void testGetDay()
	{
		Assert.assertEquals(day, date1.getDay());
	}
	
	@Test
	public void testGetMonth()
	{
		Assert.assertEquals(month, date1.getMonth());
	}
	
	@Test
	public void testGetYear()
	{
		Assert.assertEquals(year, date1.getYear());
	}
	
	@Test
	public void testDate()
	{
		String date = "Date is "+day+"/"+month+"/"+year;
		Assert.assertEquals(date, date1.toString());
	}
	
	@Test
	public void testSetDate()
	{
		date1.setDay(day);
	}
	
	@Test
	public void testSetMonth()
	{
		date1.setMonth(month);
	}
	
	@Test
	public void testSetYear()
	{
		date1.setYear(year);
	}
	
}
