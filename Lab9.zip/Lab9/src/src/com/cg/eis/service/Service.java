package src.com.cg.eis.service;

import src.com.cg.eis.bean.Employee;

interface EmployeeService
{
	public String findInsurance(int salary, String designation);
}

public class Service implements EmployeeService{
	
	String insuranceScheme = "";
	@Override
	public String findInsurance(int salary, String designation)
	{
		
		if(salary>5000 && salary<20000 && designation.equals("System Associate"))
			insuranceScheme = "Scheme C";
		else if(salary>=20000 && salary<40000 && designation.equals("Programmer"))
			insuranceScheme = "Scheme B";
		else if(salary>=40000 && designation.equals("Manager"))
			insuranceScheme = "Scheme A";
		else if(salary<5000 && designation.equals("Clerk"))
			insuranceScheme = "No Scheme";
		return insuranceScheme;
	}
	public void addObject(Employee e1) {
		// TODO Auto-generated method stub
		
	}
	
}
