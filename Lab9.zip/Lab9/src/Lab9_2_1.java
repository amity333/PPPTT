import java.util.TimerTask;

import org.junit.*;
public class Lab9_2_1 {
	static Person p = null;
	static PersonMain pm = null;
	@BeforeClass
	public static void setUp()
	{
		pm = new PersonMain();
		p = new Person("Piyush","Pathak",Gender.M, "1234567890");
		System.out.println("Testing getters and display methods");
	}
	
	
	@AfterClass
	public static void atEnd()
	{
		System.out.println("All the functions are tested successfully");
	}
	
	@Before
	public void befTest()
	{
		System.out.println("Test starts");
	}
	
	@After
	public void aftTest()
	{
		System.out.println("Test ends");
	}
	
	@Test
	public void testGetFName()
	{
		Assert.assertEquals("Piyush", p.getFirstName());
	}
	
	@Test
	public void testGetLName()
	{
		Assert.assertEquals("Pathak", p.getLastName());
	}
	
	@Test
	public void testGetPhNumber()
	{
		Assert.assertEquals("1234567890", p.getPhoneNumber());
	}
	
	@Test
	public void testGetGender()
	{
		Assert.assertEquals(Gender.M, p.getGender());
	}
	
	@Test
	public void testDisplay()
	{
		Assert.assertEquals("Person Details:\n____________First Name: Piyush\nLast Name: Pathak\nGender: M\nPhone NUmber: 1234567890",pm.displayDetails(p));
	}
	 
	
}
