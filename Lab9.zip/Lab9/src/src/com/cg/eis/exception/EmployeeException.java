//This class is created as part of question 6.3

package src.com.cg.eis.exception;
import src.com.cg.eis.pl.*;
public class EmployeeException extends Exception {
	String message;

	public EmployeeException(String message)
	{
		this.message = message;
	}
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	
}
