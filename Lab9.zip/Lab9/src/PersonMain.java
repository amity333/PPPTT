
public class PersonMain {
	static String firstName;
	static String lastName;
	static Gender gender;
	static String phoneNumber;
public static void main(String args[]) 
{
	Person person1=new Person("Piyush","Pathak",Gender.M, "1234567890");
	firstName=person1.getFirstName();
	lastName=person1.getLastName();
	gender=person1.getGender();
	phoneNumber=person1.getPhoneNumber();
	PersonMain pm = new PersonMain();
	String st = pm.displayDetails(person1);
	System.out.println(st);
}

public String displayDetails(Person p)
{
	String res = "Person Details:\n____________First Name: "+p.getFirstName()+"Last Name: "+p.getLastName()+"Gender: "+p.getGender()+"Phone NUmber: "+p.getPhoneNumber();
	return res;
}

}
